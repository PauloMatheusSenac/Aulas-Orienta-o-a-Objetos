class Categoria:
    def __init__(self, nome_categoria):
        self.nome_categoria = nome_categoria